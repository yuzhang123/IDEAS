#---------------------PARAMETERS--------------------------------------
ideaspath="./";
walltime="36:00:00"
library="export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/opt/aci/sw/quantumwise/2014.2/lib/";
folder=getwd();
host="aci-b";

#----------------FUNCTION DEFINITION----------------------------------
defheader<-function(threadn=10)
{	head=paste("#PBS -l nodes=1:ppn=",threadn,"
#PBS -l walltime=",walltime,"
#PBS -j oe
#PBS -o runpipe.script.out
cd ",
folder,
"
",library,"
PATH=$PATH:",ideaspath, "
",sep="");

	#cat(head);
	return(head);
}

runideas<-function(args, out, head, inv=NULL)
{	str=paste("ideas", paste(args, collapse=" "), "-thread", threadn, "-o", out);
	if(length(inv)==2)
	{	str=paste(str, "-inv", inv[1], inv[2]); }
	writeLines(c(head, str),paste(out,".script",sep=""));

	print(str);
	system(paste("ssh ", host, " \"cd ",folder, "; qsub ", out, ".script\"", sep=""));
	system(paste("rm ", out, ".script", sep=""));
}

combineState<-function(parafiles, method="complete", mycut=0.75)
{	X=K=NULL;
	for(i in parafiles)
	{	x=read.table(i);
		X=rbind(X, as.matrix(x));
		K=c(K,dim(x)[1]);
	}
	p = (sqrt(1 + dim(X)[2] * 8) - 3) / 2;
	mycut=round(length(parafiles)*mycut);

	M=array(X[,1:p+1]/X[,1], dim=c(dim(X)[1],p));
	V=array(0,dim=c(dim(X)[1]*p,p));
	for(i in 1:dim(X)[1])
	{	t = (i - 1) * p;
		l = 1;
		for(j in 1:p)
		{	for(k in 1:j)
			{	V[t + j, k] = V[t + k, j] = X[i,1+p+l] / X[i,1] - M[i,j] * M[i,k];
				l=l+1;
			}
		}
		V[t+1:p,]=t(solve(chol(V[t+1:p,])));
	}

	D=array(0,dim=rep(dim(X)[1],2));
	for(i in 2:dim(X)[1])
		for(j in 1:(i-1))
		{	D[i,j]=D[j,i]=sqrt((sum((V[(i-1)*p+1:p,]%*%(M[i,]-M[j,]))^2) + sum((V[(j-1)*p+1:p,]%*%(M[i,]-M[j,]))^2))/2);
		}

	h=hclust(as.dist(D),method=method);
	
	rt=NULL;
	for(i in min(K):(max(K) * 2))
	{	m=cutree(h,k=i);
		t=table(m);
		tt=(c(i,length(which(t>=mycut)),as.numeric(quantile(t,prob=0.75)-quantile(t,prob=0.25))));
		print(tt);
		rt=rbind(rt,tt);
	}

	mysel = max(which(rt[,2]==max(rt[,2]))) + min(K) - 1;
	rt=NULL;
	m=cutree(h,k=mysel);
	for(i in unique(m))
	{	t=which(m==i);
		if(length(t)>=mycut)
		{	rt=rbind(rt,apply(X[t,],2,sum));
		}
	}
	rt=rt[order(rt[,1],decreasing=T),]

	return(rt);
}

waitFiles<-function(target)
{
	k=1;
	sel=rep(0,length(target));
	while(min(sel)==0)
	{	for(i in 1:length(target))
		{	sel[i] = as.integer(file.exists(target[i]));
		}
		if(min(sel)==1) break;
		if(k%%30==0) { cat("|"); }
		else if(k%%10==0) { cat("!"); }
		else if(k%%5==0) { cat(":"); }
		else { cat("."); }
		if(k%%60==0) { cat("\n"); }
		Sys.sleep(60);
		k=k+1;
	}
	cat("\n");
}

#--------------------RUN---------------------------------------------
args<-commandArgs(trailingOnly=TRUE);
noquote(paste("args = ", paste(args,collapse=" "), collapse=""));
if(length(args) == 0)
{	print(noquote("input arguments needed"));
	quit();
}

out = args[1];
t=which(args == "-o");
if(length(t)>0)
{	out = args[t[length(t)] + 1];
	args = args[-c(t,t+1)];
}

threadn = 10;
t=which(args == "-thread");
if(length(t)>0)
{	threadn = as.integer(args[t[length(t)]+1]);
	args = args[-c(t,t+1)];
}

type=0;
if(length(args)>1 & substring(args[2],1,1)!='-') type = 1;

inv=NULL;
t=which(args == "-inv");
if(length(t)>0)
{	inv = c(as.integer(args[t[length(t)]+1]), as.integer(args[t[length(t)]+2]));
	args = args[-c(t,t+1,t+2)];
}else
{	if(type == 1)
	{	a=system(paste("wc -l", args[2]), intern=TRUE)
	}else 
	{	a=system(paste("wc -l", args[1]), intern=TRUE)
	}
	inv=c(0, as.integer(strsplit(a," ")[[1]][1]));
}

randstart = c(10, 100000);
t=which(args == "-randstart");
if(length(t)>0)
{	randstart[1] = as.integer(args[t[length(t)]+1]);
	randstart[2] = as.integer(args[t[length(t)]+2]);
	args = args[-c(t, t+1, t+2)];
}
randstart[2] = min(randstart[2], inv[2] - inv[1]);

split = NULL;
t=which(args == "-split");
if(length(t)>0)
{	split = args[t[length(t)]+1];
	args = args[-c(t,t+1)];
}

burnin = 20; mcmc = 1;
t=which(args == "-sample");
if(length(t)>0)
{	burnin = as.integer(args[t[length(t)]+1]);
	mcmc = as.integer(args[t[length(t)]+2]);
	args = args[-c(t,t+1,t+2)];
}
args = c(args, "-sample", burnin, mcmc);

head=defheader(threadn);

listfile = args[1];
if(type==1)
{	y=as.matrix(read.table(args[1]));
	ny=y;
	for(i in 1:dim(y)[1])
	{	a=unlist(strsplit(y[i,3],"\\."));
		if(a[length(a)]=="gz")
		{	ny[i,3] = paste(out, ".tmpdata.", i, sep="");	
			system(paste("gunzip -cf", y[i,3], ">", ny[i,3]));
		}
	}
	if(length(which(y[,3]!=ny[,3]))>0)
	{	args[1] = paste(out, ".newinput", sep="");
		write.table(ny, args[1], quote=F, row.names=F,col.names=F);
	}
}

if(randstart[1]>0)
{	targs = args;
	#tburnin = 20; tmcmc = 1;
	#t=which(targs == "-sample");
	#if(length(t)>0)
	#{	targs = targs[-c(t,t+1,t+2)];
	#}
	#targs = c(targs, "-sample", tburnin, tmcmc);
	for(i in 1:randstart[1])
	{	tout = paste(out, ".tmp.",i, sep=""); 
		tinv = round(runif(1, inv[1], inv[2]-randstart[2]));
		tinv = c(tinv, tinv + randstart[2]);
		if(file.exists(paste(tout, ".para", sep="")))
		{	system(paste("rm ", tout, ".para", sep=""));
		}
		runideas(targs, tout, head, tinv);
		Sys.sleep(1);
	}
	
	waitFiles(paste(out, ".tmp.", 1:randstart[1], ".para", sep=""));

	para = combineState(paste(out,".tmp.",1:randstart[1],".para",sep=""));
	para = apply(para, 1, function(x){paste(x,collapse=" ")});
	para = c(readLines(paste(out, ".tmp.1.para",sep=""),n=1), para);

	for(i in 1:randstart[1])
	{	system(paste("rm ", out, ".tmp.",i,".*", sep=""));
	}

	outp = paste(out, ".para0", sep="");
	writeLines(para, outp);
	args = c(args, "-otherpara", outp); 
	if(length(which(args == "-G")) == 0) { args = c(args, "-G", length(para)-1); }
}

if(length(split) > 0)
{	inv = as.matrix(read.table(split));
}else
{	inv = array(c("",inv), dim=c(1, 3));
}

target = NULL;
for(i in 1:dim(inv)[1])
{	if(dim(inv)[1]==1) { target[i] = out; }
	else { target[i] = paste(out, inv[i,1], sep="."); }
	if(file.exists(paste(target[i], ".para", sep="")))
	{	system(paste("rm ", target[i], ".para", sep=""));
	}
	runideas(args, target[i], head, inv[i,-1]);
}

waitFiles(paste(target, ".para",sep=""));

if(listfile != args[1])
{	y=as.matrix(read.table(listfile));
	ny=as.matrix(read.table(args[1]));
	for(i in 1:dim(y)[1])
	{	if(y[i,3]!=ny[i,3])
		{	system(paste("rm",ny[i,3]));
		}
	}
	system(paste("rm",args[1]));
}

